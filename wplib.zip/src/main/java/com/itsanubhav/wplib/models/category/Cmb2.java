package com.itsanubhav.wplib.models.category;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class Cmb2{

	@SerializedName("wordroid_fields")
	private WordroidFields wordroidFields;

	public WordroidFields getWordroidFields() {
		return wordroidFields;
	}

	public void setWordroidFields(WordroidFields wordroidFields) {
		this.wordroidFields = wordroidFields;
	}
}